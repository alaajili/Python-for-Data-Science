def count_in_list(lst, item):
    """
    return the number of items (item) in a list (lst)
    """
    return lst.count(item)